function names = ensembleModels1()

%   Copyright 2010-2011 The MathWorks, Inc.


names = {'AdaBoostM1' 'AdaBoostM2' 'AdaBoostMH' 'RobustBoost' ...
    'LogitBoost' 'GentleBoost' 'LSBoost' 'Bag' 'Subspace' ...
    'RUSBoost' 'LPBoost' 'TotalBoost'};
end
